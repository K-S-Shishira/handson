use uni_manage_sys;
#Problem #1
select sinfo.student_name, sinfo.reg_number, sresult.gpa from student_info_2095554 as sinfo
inner join student_result_2095554 as sresult on sresult.Reg_Number = sinfo.reg_number order by sresult.gpa desc;
#Problem #2
select * from student_info_2095554 order by student_name asc;
#Problem #3
select * from student_info_2095554 order by datediff(date_of_joining, date_of_birth) asc;
#Problem #4
select sinfo.reg_number, sinfo.student_name, semester, gpa from student_info_2095554 as sinfo
inner join student_result_2095554 as sresult on sresult.Reg_Number = sinfo.reg_number
order by sresult.gpa desc;
#Problem #5
select reg_number, gpa from student_result_2095554 order by Is_Eligible_Scholarship desc;
#Problem #6
select reg_number, gpa from student_result_2095554 order by Is_Eligible_Scholarship desc;
#Problem #7
select * from student_info_2095554 as sinfo
inner join student_result_2095554 as sresult on sresult.reg_number = sinfo.reg_number
where sresult.gpa in (select  max(gpa) from student_result_2095554 group by semester);
#Problem #8
select * from student_info_2095554 as sinfo
inner join student_result_2095554 as sresult on sresult.reg_number = sinfo.reg_number
where sresult.gpa in (select  min(gpa) from student_result_2095554 group by semester);