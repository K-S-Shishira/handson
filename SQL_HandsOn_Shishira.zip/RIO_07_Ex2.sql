use uni_manage_sys;
#Ex-1
select student_name, subject_code, marks from student_marks_2095554 as smarks
inner join student_info_2095554 as sinfo on sinfo.reg_number = smarks.Reg_Number;
#Ex-2
select student_name, subject_code,marks from student_marks_2095554 as smarks
inner join student_info_2095554 as sinfo on sinfo.reg_number = smarks.reg_number
where smarks.Reg_Number not in (select Reg_Number from student_marks_2095554 where marks<65) ;
#Ex-3
select si.reg_number, student_name, gpa from student_info_2095554 as si
inner join student_result_2095554 as sr on sr.Reg_Number = si.reg_number
where gpa = (select max(gpa) from student_result);
#Ex-4
create table backup_student_info_2095554(reg_number varchar(20) primary key , student_name  varchar(30) not null, branch varchar(30), contact_number varchar(20),
date_of_birth date not null, date_of_joining date default(current_date), address varchar(250), mail_id varchar(250), foreign key (reg_number) references student_info_2095554(reg_number));
insert into backup_student_info_2095554 select * from student_info_2095554;
insert into student_info_2095554 values
('MC101305' ,'Jamie', 'BCA' ,'9714589788', '1983-1-12', '2011-7-08','No 7,South Block Nivea', 'jamie.bca@yahoo.com'),
('BEC111408' ,'Marie', 'ECE', '8912457888', '1983-2-27', '2011-8-25','8/12,manyata Park View,Sieera', 'marie@gmail.com');
select * from student_info_2095554 as sinfo 
left outer join backup_student_info_2095554 as bup on bup.Reg_Number = sinfo.reg_number;
#Ex-5
select * from backup_student_info_2095554 as bup
right outer join student_info_2095554 as sinfo on sinfo.reg_number = bup.Reg_Number;