#Ex-3.1
use uni_manage_sys;

set sql_safe_updates=0;
start transaction;
alter table student_info_2095554 add constraint primary key(reg_number);
update student_info_2095554 set student_name=not null;
alter table student_info_2095554 alter column date_of_joining set default(current_date());

alter table subject_master_2095554 add constraint primary key(subject_code);
update subject_master_2095554 set subject_name=not null, weightage=not null;

alter table student_marks_2095554 add constraint foreign key(reg_number) references student_info_2095554(reg_number);
alter table student_marks_2095554 add constraint foreign key(subject_code) references subject_master_2095554(subject_code);
update student_marks_2095554 set semester=not null;
alter table student_marks_2095554 alter column marks set default(0);

alter table student_result_2095554 add constraint foreign key(reg_number) references student_info_2095554(reg_number);
update student_result_2095554 set semester=not null, GPA=not null;
alter table student_result_2095554 alter column is_eligible_scholarship set default('Yes');

#Ex-3.2
alter table subject_master_2095554 add constraint unique(subject_name);
alter table student_info_2095554 add constraint unique(contact_number);
alter table student_info_2095554 add constraint check(date_of_joining>date_of_birth);
alter table student_marks_2095554 add constraint check(marks<=100);
alter table student_result_2095554 add constraint check(GPA<=10);
alter table student_result_2095554 add constraint check(is_eligible_scholarship='Y' or is_eligible_scholarship='N');
set sql_safe_updates=1;