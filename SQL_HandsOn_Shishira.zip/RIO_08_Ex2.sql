use uni_manage_sys;

#Ex-1
select si.student_name,marks, sm.Reg_Number, subject_code from student_marks_2095554 as sm
inner join student_info_2095554 as si on si.reg_number = sm.Reg_Number
where sm.Reg_Number in (select reg_number from student_marks_2095554 group by subject_code having max(marks));
#Ex-2
select si.reg_number , si.student_name, sm.marks from student_marks_2095554 as sm
inner join student_info_2095554 as si on si.reg_number = sm.reg_number
where sm.Reg_Number in (select reg_number from student_marks_2095554 group by subject_code having max(marks)) and subject_code = 'EI05IP'; 
#Ex-3
select student_name, reg_number from student_info_2095554 where
reg_number = (select reg_number from student_marks_2095554 where subject_code = 'EI05IP' order by marks desc limit 1 offset 1);
#Ex-4
select reg_number from student_marks_2095554 where marks > (select avg(marks) from student_marks_2095554 where subject_code = 'EI05IP');