use uni_manage_sys;
#Ex-1
create view   STUDENT_GPA_emp_id as
select si.student_name, sr.reg_number, sr.semester, sr.GPA from student_result_2095554 as sr
join student_info_2095554 as si on si.reg_number = sr.reg_number;
#Ex-2
select * from STUDENT_GPA_emp_id where gpa>5;
#Ex-3
create or replace view STUDENT_AVERAGE_GPA_emp_id as select si.student_name, sr.reg_number,
avg(gpa) 'average_gpa' from student_result_2095554 as sr
join student_info_2095554 as si on si.reg_number = sr.Reg_Number group by reg_number;
select * from student_average_gpa_emp_id;
#Ex-4
SELECT * from student_average_gpa_emp_id where average_gpa>7;
#Ex-5
create index index_1 on student_marks(semester);
alter table student_marks_2095554 drop index index_1 ;
#Ex-6
 create unique index index_2 on student_info_2095554(email_id);