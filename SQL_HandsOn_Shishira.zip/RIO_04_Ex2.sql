use uni_manage_sys;

#Problem #1
select * from student_info_2095554 where email_id is not null;
#Problem #2
select reg_number,marks from student_marks_2095554 where marks>50;
#Problem #3
select sinfo.reg_number, sinfo.student_name, smaster.subject_name, smarks.Semester, smarks.marks from student_marks_2095554 as smarks
inner join student_info_2095554 as sinfo on sinfo.reg_number = smarks.Reg_Number
inner join subject_master_2095554 as smaster on smaster.subject_code = smarks.subject_code;
#Problem #4
select sinfo.student_name, sinfo.reg_number,smaster.subject_code, smaster.subject_name,
smarks.marks,smarks.semester from student_marks_2095554 as smarks
inner join student_info_2095554 as sinfo on sinfo.reg_number = smarks.reg_number 
inner join subject_master_2095554 as smaster on smaster.subject_code = smarks.subject_code
where smarks.marks >50;
#Problem #5
select is_eligible_scholarship,reg_number,GPA from student_result_2095554 where is_eligible_scholarship='Y';
#Problem #6
select sinfo.reg_number, sinfo.student_name, smarks.marks,(smaster.weightage* smarks.marks/100) as weighted_marks from student_marks_2095554 as smarks
inner join subject_master_2095554 as smaster on smarks.subject_code = smaster.subject_code
inner join student_info_2095554 as sinfo on sinfo.reg_number = smarks.Reg_Number ;
#Problem #7
select student_name from student_info_2095554 where student_name like 'm%';
#Problem #8
select sinfo.student_name, sinfo.reg_number, smarks.marks from student_marks_2095554 as smarks
inner join student_info_2095554 as sinfo on sinfo.reg_number = smarks.Reg_Number
where smarks.marks >= 60 and smarks.marks <= 100;
#Problem #9
select sinfo.student_name, sinfo.reg_number, smarks.marks from student_marks_2095554 as smarks
inner join student_info_2095554 as sinfo on sinfo.reg_number = smarks.reg_Number
where smarks.marks >= 60 and smarks.marks <= 100;
#Problem #10
select sinfo.student_name, sinfo.reg_number, smarks.marks from student_info_2095554 as sinfo
inner join student_marks_2095554 as smarks on sinfo.reg_number = smarks.Reg_Number
where student_name not like 'j%';
#Problem #11
select sinfo.student_name, sinfo.reg_number, smarks.marks from student_marks_2095554 as smarks
inner join student_info_2095554 as sinfo on sinfo.reg_number = smarks.Reg_Number
where smarks.subject_code in ('EE01DCF', 'EC02MUP');
#Problem #12
select * from student_info_2095554 where student_name like '%on';