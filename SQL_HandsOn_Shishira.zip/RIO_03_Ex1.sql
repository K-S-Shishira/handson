use ansi_sql_handson;
#Ex-3.1
set sql_safe_updates=0;
alter table trainer_info add constraint primary key(trainer_id);
update trainer_info set trainer_id=not null, salutation=not null, trainer_name=not null, trainer_location=not null, trainer_track=not null, trainer_qualification=not null, trainer_email=not null, trainer_password=not null;
alter table trainer_info add constraint check (trainer_id like 'f%');

alter table batch_info add constraint primary key(batch_id);
update batch_info set batch_id=not null, batch_owner=not null, batch_BU_name=not null;
alter table batch_info add constraint check (batch_id like 'b%');

alter table module_info add constraint primary key(module_id);
update module_info set module_id=not null, module_name=not null, module_duration=not null;
alter table trainer_info add constraint mid_upper check (binary (module_id)=binary upper(module_id));

alter table associate_info add constraint primary key(associate_id);
update associate_info set associate_id=not null, salutation=not null, associate_name=not null, associate_location=not null, associate_track=not null, associate_qualification=not null, associate_email=not null, associate_password=not null;
alter table associate_info add constraint check (associate_id like 'a%');

alter table questions add constraint primary key(question_id);
alter table questions add constraint foreign key(module_id) references module_info(module_id);
update questions set question_id=not null, question_text=not null;
alter table questions add constraint check (question_id like 'q%');

alter table associate_status add constraint foreign key (associate_id) references associate_info(associate_id);
alter table associate_status add constraint foreign key (module_id) references module_info(module_id);
alter table associate_status add constraint foreign key (batch_id) references batch_info(batch_id);
alter table associate_status add constraint foreign key (trainer_id) references trainer_info(trainer_id);
update associate_status set associate_id=not null, module_id=not null, batch_id=not null, trainer_id=not null;

update trainer_feedback set trainer_id=not null, question_id=not null, batch_id=not null, module_id=not null, trainer_rating=not null;
alter table trainer_feedback add constraint foreign key (trainer_id) references trainer_info(trainer_id);
alter table trainer_feedback add constraint foreign key (question_id) references questions(question_id);
alter table trainer_feedback add constraint foreign key (batch_id) references batch_info(batch_id);
alter table trainer_feedback add constraint foreign key (module_id) references module_info(module_id);

update associate_feedback set associate_id=not null, question_id=not null, module_id=not null, module_id=not null, associate_rating=not null;
alter table associate_feedback add constraint foreign key (associate_id) references associate_info(associate_id);
alter table associate_feedback add constraint foreign key (question_id) references questions(question_id);
alter table associate_feedback add constraint foreign key (module_id) references module_info(module_id);

#Ex-3.2
create table product(product_id int primary key, product_name varchar(20), product_price int not null);
#update product set product_price=00;
create table user_table(user_id varchar(10) primary key, product_id int, user_name varchar(20));
alter table user_table add constraint fk_product_id foreign key (product_id) references product(product_id);
insert into product values (1, 'A Dongle', 290), (2,'B Dongle',1250), (3,'C Dongle',000);

alter table user_table drop constraint fk_product_id;
insert into user_table values('U001',1,'Ramesh'),('U002',11,'Mahesh');
#here the values are inserted upon execution as the foreign key constraint is dropped hence altering the values is allowed
alter table user_table add constraint fk_product_id foreign key(product_id) references product(product_id);
#adding foreign key again is not possible as changes have already been made in the table and altering values would affect the primary key of parent table 
set sql_safe_updates=1;