use ansi_sql_handson;
#Problem #1
select trainer_name from trainer_info where trainer_email is null;
#Problem #2
select trainer_id, trainer_name, trainer_track, trainer_location from trainer_info where trainer_experience>4;
#Problem #3
select module_id, module_name from module_info where module_duration>200;
#Problem #4
select trainer_id, trainer_name from trainer_info where trainer_qualification!='Bachelor of technology';
#Problem #5
select module_id, module_name from module_info where module_duration>200 and module_duration<300;
#Problem #6
select trainer_id, trainer_name from trainer_info where trainer_name like '%o%';
#Problem #7
select module_name from module_info where module_name is not null;